//  local
// const BASE_URL = "https://ssknf82q-3009.inc1.devtunnels.ms/api/" 

//  railaway
const BASE_URL = "https://afsana-backend-production-0897.up.railway.app/api/"
// const BASE_URL = "https://afsana-backend-production-4b65.up.railway.app/api/"


export default BASE_URL      